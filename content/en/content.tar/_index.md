---
title: "Serene Lake PTSA"
description: "Supporting students, teachers, and families at Serene Lake Elementary School in Mukilteo School District"
layout: home
banner: "/img/banner.png"
---

## Supporting Our Students, Teachers, and Families

We're the parent-teacher organization at Serene Lake Elementary School in Mukilteo School District. Join us in creating an amazing school community!
