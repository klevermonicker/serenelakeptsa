---
title: "Staff Favorites"
description: "Get to know the amazing teachers and staff at Serene Lake Elementary"
layout: staff-favorites
---

Get to know our wonderful teachers and staff! Here are some fun facts and favorites from the people who make Serene Lake Elementary special.
