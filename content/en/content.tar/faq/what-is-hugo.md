---
title: "What is Hugo?"
weight: 1
noindex: true
---

Hugo is a static site generator written in Go. It's fast and flexible.